# Equality News Website

A responsive single-page Equality News breaking-news website based on the supplied design.

## GitHub Pages

1. Create a GitHub repository.
2. Upload `index.html`.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`.
6. Save and wait for GitHub Pages to publish the site.

The **Learn More** button scrolls directly to the full story.
